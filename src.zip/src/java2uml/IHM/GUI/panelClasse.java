package java2uml.IHM.GUI;

import java.awt.*;
import javax.swing.*; 

public class panelClasse {
	
}
